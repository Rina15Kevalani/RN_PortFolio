export interface Education{
  institute:string;
  course:string;
  duration: string;
  grade:string;
}
